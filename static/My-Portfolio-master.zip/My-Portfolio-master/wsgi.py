from app import app
if __name__ == "_main_":
    app.run(debug=True)
